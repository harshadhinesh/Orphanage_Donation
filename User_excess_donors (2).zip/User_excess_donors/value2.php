<?php
session_start();

require_once("admin/includes/dbconnection.php");
$id=$_POST['id'];
echo $id;
$sql="select * from  tbldonors where ID=$id";
$qry=mysqli_query($dbh,$sql);
while($row=mysqli_fetch_assoc($qry))
{
	$orname=$row['name'];
	$ownerid=$row['owner'];
	$area=$row['area'];
}

$donates=$_POST['donates'];
echo $donates;
$price=$_POST['price'];
echo $price."<br>";

$donorsname=$_SESSION['yourname'];
$phone=$_SESSION['phone'];
$cdate=date("Y-m-d");
$status=1;
echo $donorsname;
$sql="INSERT INTO `tbldonate`(`orphanagename`,`ownerid`,`area`,`donates`,`price`,`donorsname`,`donorsphone`,`cdate`,`status`) 
VALUES ('$orname','$ownerid','$area','$donates','$price','$donorsname','$phone','$cdate','$status')";
echo $sql;
$query=mysqli_query($dbh,$sql);
if($query)
{
	echo "record added sucessfully";
	header("Location:donate.php");
}
else{
	echo "wrong";
}

?>

