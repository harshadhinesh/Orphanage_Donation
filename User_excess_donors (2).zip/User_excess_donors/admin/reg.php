<?php
session_start();
//error_reporting(0);
include_once("includes/dbconnection.php");
?>
<!doctype html>
<html lang="en">

    <head>
       
        <title>Orphanage Registration</title>

        <!-- Bootstrap CSS -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

        <!-- App CSS -->
        <link href="assets/css/style.css" rel="stylesheet" type="text/css" />

        <!-- Modernizr js -->
        <script src="assets/js/modernizr.min.js"></script>
		

    </head>


    <body>

        <div class="account-pages"></div>
        <div class="clearfix"></div>
        <div class="wrapper-page">

        	<div class="account-bg">`
                <div class="card-box mb-0">
                    <strong style="padding-top: 30px;"><a href="../index.php" class="text-muted"><i class="fa fa-home m-r-5"></i> Back Home!!</a> </strong>
					<strong style="padding-top: 30px;"><a href="login.php" class="text-muted"><i class="fa fa-user" aria-hidden="true"></i> Login!!</a> </strong>
                    <div class="text-center m-t-20">
                            <i class="zmdi zmdi-group-work icon-c-logo"></i>
                            <span>Orphanage Registration</span>
                    </div>
                    <div class="m-t-10 p-20">
                        <div class="row">
                            <div class="col-12 text-center">
                                <h6 class="text-muted text-uppercase m-b-0 m-t-0">Register</h6>
                            </div>
                        </div>
                        <form class="m-t-20" action="insert.php" method="post">

                            <div class="form-group row">
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="Enter your Orphanage name" required="true" name="OrphanageName" value="<?php if(isset($_COOKIE["user_login"])) { echo $_COOKIE["user_login"]; } ?>" >
                                </div>
                            </div>
							<div class="form-group row">
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="Enter your Owner name" required="true" name="AdminName" value="<?php if(isset($_COOKIE["user_login"])) { echo $_COOKIE["user_login"]; } ?>" >
                                </div>
                            </div>
							 <div class="form-group row">
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="Enter your Email" required="true" name="Email"  >
                                </div>
                            </div>
							<div class="form-group row">
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="Enter your Mobile number" required="true" name="MobileNumber"  >
                                </div>
                            </div>
									
                             <div class="form-group row">
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="Enter your Username" required="true" name="UserName"  >
                                </div>
                            </div>
                           
							<div class="form-group row">
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="Enter your Password" required="true" name="Password"  >
                                </div>
                            </div>
							
					

                         

                            <div class="form-group text-center row m-t-10">
                                <div class="col-12">
                                    <button class="btn btn-success btn-block waves-effect waves-light" type="submit" name="submit">Submit</button>
                                </div>
                            </div>

                     
                     


                        </form>

                    </div>

                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- end card-box-->


        </div>
        <!-- end wrapper page -->
        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="../plugins/switchery/switchery.min.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

    </body>
</html>