<?php
session_start();
require_once("admin/includes/dbconnection.php");
$id=$_POST["id"];
//echo $id;
$updateperson=$_SESSION['yourname'];
echo $updateperson;
$full_name=$_POST['full_name'];
echo $full_name;
$user_name=$_POST['user_name'];
echo $user_name;
$phone_number=$_POST['phone_number'];
echo $phone_number;
$email=$_POST['email'];
echo $email;
$password=$_POST['password'];
echo $password;
$confirm_password=$_POST['confirm_password'];
echo $confirm_password;
$udate=date("Y-m-d");
$status=1;
$sql="UPDATE`tbluser`SET`fullname`='$full_name',`username`='$user_name',`phonenumber`='phone_number',`email`='$email',`password`='$password',`confirmpassword`='$confirm_password',`udate`='$udate',`updateperson`='$updateperson',`status`='$status' WHERE id=$id"; 
$query=mysqli_query($dbh,$sql);
if($query)
{
	echo "record added sucessfully";
	header("Location:homefrom.php");
}
else{
	echo "wrong";
}

?>

