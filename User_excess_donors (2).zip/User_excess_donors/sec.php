<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<?php
session_start();
require_once("admin/includes/dbconnection.php.");
$id=$_GET['id'];
echo $_SESSION['yourname'];
$sql="select * from tbluser where id=$id and status=1";
$qry=mysqli_query($dbh,$sql);
while($result=mysqli_fetch_assoc($qry))
{
	$yourname=$result['yourname'];
    $youremail=$result['youremail'];
    $password=$result['password'];
}
?>
<form method="post" action="edit2.php" enctype="multipart/form-data">

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                       <label class="form-label" for="form3Example1c">Your Name</label>
                      <input type="text" id="form3Example1c" class="form-control" name="your_name" value="<?php echo $yourname;?>">
					  <input type="hidden" name="id" value="<?php echo $id;?>">
                    
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <label class="form-label" for="form3Example3c">Email</label>
                      <input type="email" id="form3Example3c" class="form-control" name="your_email" value="<?php echo $youremail;?>">
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
					  <label class="form-label" for="form3Example4c">Password</label> 
					  <input type="password" id="for3Example4c" class="from=control" name="password" value="<?php echo $password;?>">
                    </div>
					
					</div> <div class="d-flex justify-content-center">
                  <INPUT type="submit"
                    class="btn btn-success btn-block btn-lg gradient-custom-4 text-body" VALUE="Button">
					</div>
					
</form>