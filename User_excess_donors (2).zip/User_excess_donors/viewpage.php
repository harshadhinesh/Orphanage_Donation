<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<?php
session_start();
require_once("admin/includes/dbconnection.php");
$sql="select * from tbluser where status=1";
$qry=mysqli_query($conn,$sql);
?>
<h1> <?php echo $_SESSION['yourname'];?><h1>
<h3><a href="text">Logout</a></h3>
<table class="table table-bordered">
    <thead>
      <tr>
        <th>Full Name</th>
        <th>Email</th>
        <th>Password</th>
		<th>User Name</th>
		<th>Phone Number</th>
		<th>Confirm Password</th>
	
      </tr>
    </thead>
    <tbody>
      
<?php
while($result=mysqli_fetch_assoc($qry))
{
	$id=$result['id'];
	$fullname=$result['fullname'];
    $email=$result['email'];
    $password=$result['password'];
    $username=$result['username'];
    $phonenumber=$result['phonenumber'];
    $confirmpassword=$result['confirmpassword'];
   

	echo "<tr>"; 
	echo "<td>".$fullname."</td>";
	echo "<td>".$email."</td>";
	echo "<td>".$password."</td>";
	echo "<td>".$username."</td>";
	echo "<td>".$phonenumber."</td>";
	echo "<td>".$confirmpassword."</td>";
	?>
	<td> <a href="editpage2.php?id=<?php echo $id;?>"> Edit
	<a href="deletepage.php?id=<?php echo $id;?>">Delete </td>
	</tr>
	
<?php }
?>
        
      
    </tbody>
  </table>


