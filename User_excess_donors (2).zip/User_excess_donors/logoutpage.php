<?php
session_start();
require_once("admin/includes/dbconnection.php");
session_destroy();
header("Location:index.php");
?>