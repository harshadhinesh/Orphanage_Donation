<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['ifscaid']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
  {

$ifscaid=$_SESSION['ifscaid'];
 $name=$_POST['name'];
 $city=$_POST['city'];
 $donates=$_POST['donates'];
 $price=$_POST['price'];
 
$sql="insert into tbldonates(name,city,donates,price,)values('$name','$city','$donates','$price',)";
$query=mysqli_query($dbh,$sql);
if ($query==TRUE) {
    echo '<script>alert("Donors  has been added.")</script>';
echo "<script>window.location.href ='add-donates.php'</script>";
  }
  else
    {
         echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }

  
}

?>
<!doctype html>
<html lang="en">

    <head>
       
        <title>Orpahane Donation :: Donates Details</title>

        <!-- Switchery css -->
        <link href="../plugins/switchery/switchery.min.css" rel="stylesheet" />

        <!-- Bootstrap CSS -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

        <!-- App CSS -->
        <link href="assets/css/style.css" rel="stylesheet" type="text/css" />

        <!-- Modernizr js -->
       
    </head>


    <body>
	
	
 <body>
  <div class="container">
    <div class="title">Donates</div>
    <div class="content">
      <form action="func.php" method="post">
        <div class="user-details" style="background-image: url(assets/images/footer-bg.jpg)"> 
          <div class="input-box">
		   <label for="cars">Orphanage Name</label>

<select name="name" id="cars">
<?php
$sql="select * from tbldonors";
$qry=mysqli_query($dbh,$sql);
while($row=mysqli_fetch_assoc($qry))
{
	$orphanagename=ucfirst($row['name']);
	?>
  <option value="<?php echo $orphanagename;?>"><?php echo $orphanagename;?></option>
<?php  
}?>
</select>

         
          
          </div>
          <div class="input-box">
		  <label for="cars">City</label>

<select name="city" id="cars">
<?php
$sql="select * from tbldonors";
$qry=mysqli_query($dbh,$sql);
while($row=mysqli_fetch_assoc($qry))
{
	$city=ucfirst($row['city']);
	?>
  <option value="<?php echo $city;?>"><?php echo $city;?></option>
<?php  
}?>
</select>
           
          </div>
          <div class="input-box">
            <span class="details">Donates</span>
            <input type="text"  name="donates" required>
          </div>
          <div class="input-box">
            <span class="details">Approximate Price</span>
            <input type="text" name="price" required>
          </div>
        </div>
           <div class="text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div> 
  </div>

   

<?php include_once('includes/footer.php');?>

        </div> <!-- End wrapper -->

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="../plugins/switchery/switchery.min.js"></script>

        <!-- Validation js (Parsleyjs) -->
        <script src="../plugins/parsleyjs/parsley.min.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

        <script>
            $(document).ready(function() {
                $('form').parsley();
            });
        </script>

    </body>
</html><?php }  ?>