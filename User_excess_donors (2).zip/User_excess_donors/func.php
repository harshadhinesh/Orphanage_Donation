<?php
require_once("admin/includes/dbconnection.php");

$full_name=$_POST['full_name'];

$email=$_POST['email'];
echo $email;
$password=$_POST['password'];
echo $password;
$user_name=$_POST['user_name'];
echo $user_name;
$phone_number=$_POST['phone_number'];
echo $phone_number;
$confirm_password=$_POST['confirm_password'];
echo $confirm_password;
$cdate=date("Y-m-d");
$status=1;
$sql="INSERT INTO `tbluser`(`fullname`,`email`,`password`,`username`,`phonenumber`,`confirmpassword`, `cdate`,`status`) 
VALUES ('$full_name','$email','$password','$user_name','$phone_number','$confirm_password','$cdate','$status')";
echo $sql;
$query=mysqli_query($dbh,$sql);
if($query)
{
	echo "record added sucessfully";
	header("Location:loginfresh.php");
}
else{
	echo "wrong";
}

?>

