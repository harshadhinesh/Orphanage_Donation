<?php
session_start();
require_once("admin/includes/dbconnection.php");
$id=$_POST["id"];
//echo $id;
$updateperson=$_SESSION['yourname'];
echo $updateperson;
$full_name=$_POST['full_name'];
$user_name=$POST['user_name'];
echo $user_name;

$email=$_POST['email'];
//echo $your_email;
$phone_number=$_POST['phone_number'];
echo $phone_number;
$password=$_POST['password'];
//echo $password;
$udate=date("Y-m-d");
$status=1;
$sql="UPDATE`tbluser`SET `fullname`= '$full_name',`username`='$user_name',`email`='$email',`phonenumber`='$phone_number',`password`='$password',`udate`='$udate',`updateperson`='$updateperson',`status`='$status' WHERE id=$id"; 
$query=mysqli_query($conn,$sql);
if($query)
{
	echo "record added sucessfully";
	header("Location: test.php");
}
else{
	echo "wrong";
}

?>


