<?php
session_start();
require_once("admin/includes/dbconnection.php");
$email=$_POST['email'];
$password=$_POST['password'];
//echo $email;
//echo $password;
$sql="select * from tbluser where email='$email' and password='$password' and status=1";
//echo $sql;
$qry=mysqli_query($dbh,$sql);
$rowcount=mysqli_num_rows($qry);
echo $rowcount;
if($rowcount==0)
{
	?>
	<script type = "text/javascript">  
           alert ("Username Or Password or Wrong");  
		   window.location.href = "loginfresh.php";
             
      </script>
<?php	  
	//header("Location:loginfresh.php");
}
else{
while($row=mysqli_fetch_assoc($qry))
{
	//echo "hi";
	$_SESSION['id']=$row['ID'];
	$_SESSION['yourname']=$row['fullname'];
	$_SESSION['phone']=$row['phonenumber'];
	
	header("Location:homefrom.php");
}
}	
?>