<?php
require_once("admin/includes/dbconnection.php");
$id=$_GET['id'];
$status=2;
$sql="UPDATE `tbluser` SET `status`='$status' WHERE id=$id";
$qry=mysqli_query($conn,$sql);
if($qry)
{
	echo "record added sucessfully";
	header("Location:func.php");
}
else{
	echo"wrong";
}
?>
