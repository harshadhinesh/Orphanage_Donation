
<?php
require_once("includes/dbconnection.php");
$OrphanageName=$_POST['OrphanageName'];
echo $OrphanageName;
$AdminName=$_POST['AdminName'];

$Email=$_POST['Email'];
echo $Email;
$MobileNumber=$_POST['MobileNumber'];
echo $MobileNumber;
$UserName=$_POST['UserName'];
echo $UserName;
$Password=$_POST['Password'];
echo $Password;
$AdminRegdate=date("Y-m-d");
$status=1;
$sql="INSERT INTO `tbladmin`(`OrphanageName`,`AdminName`,`Email`,`MobileNumber`,`UserName`, `Password`,`AdminRegdate`) 
VALUES ('$OrphanageName','$AdminName','$Email','$MobileNumber','$UserName','$Password','$AdminRegdate')";
echo $sql;
$query=mysqli_query($dbh,$sql);
if($query)
{
	echo "record added sucessfully";
	header("Location:login.php");
}
else{
	echo "wrong";
}

?>


?>